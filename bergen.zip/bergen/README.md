# Bergen 11–17 agosto 2026

Sito statico: itinerario del viaggio e tracker delle spese con budget di 1.800 €.
Nessuna build, nessuna dipendenza, nessun framework. Sono quattro file.

## Metterlo online su Vercel

### Vercel Drop, il modo più veloce

1. Vai su **vercel.com/drop** e fai login.
2. **Trascina lo zip così com'è.** Non serve scompattarlo: Drop accetta file, cartelle e archivi .zip.
3. Scegli il team e dai un nome al progetto.
4. Premi **Deploy**. In pochi secondi il sito è online in produzione, con un URL pubblico.

Non serve configurare niente: nessun framework, nessun build command, nessuna output directory.
C'è un `index.html` alla radice, quindi Vercel lo serve come homepage senza chiedere nulla.

**Limite importante:** ogni drop crea un progetto nuovo con un URL nuovo. Non aggiorna un progetto
esistente. Se prevedi di modificare l'app più volte, fai il drop solo quando hai la versione buona,
oppure collega un repository Git al progetto dopo il primo deploy.

### Via GitHub, se vuoi aggiornarlo nel tempo

Carica la cartella in un repository, poi su Vercel scegli **Add New → Project → Import Git Repository**.
Da lì in poi ogni push aggiorna il sito allo stesso URL.

### Via terminale

```bash
npm i -g vercel
cd bergen
vercel --prod
```

Alla domanda sul framework rispondi `Other` e lascia vuoti build e output.

## Installarlo sul telefono

Apri l'URL su iPhone in Safari, tocca Condividi e poi **Aggiungi alla schermata Home**.
Su Android, Chrome propone **Installa app**. Parte a tutto schermo, senza barra del browser.

## Funziona senza connessione

C'è un service worker che mette in cache tutto alla prima apertura.
Apri il sito almeno una volta con il wifi **prima di partire**: dopo funziona anche
in mezzo al Sognefjord senza campo.

## Dove finiscono i dati

Le spese restano nel `localStorage` del browser che usi, non su un server.
Due conseguenze da tenere a mente:

- **Non si sincronizzano tra i tuoi due telefoni.** Decidete chi tiene i conti.
- Se cancelli i dati di navigazione del sito, le spese spariscono.

## Modificare i contenuti

Tutto è dentro `index.html`, in fondo, nel blocco `<script>`:

- `PLAN` — il preventivo per categoria, in euro
- `DAYS` — l'itinerario giorno per giorno
- `CATS` — le categorie di spesa

Budget totale e cambio NOK/EUR si cambiano direttamente dall'interfaccia,
in fondo alla scheda Spese.

Se modifichi i file e ridistribuisci, alza `CACHE` in `sw.js` (`bergen-2026-v2`),
altrimenti il telefono continua a mostrare la versione vecchia.

## File

```
index.html            l'app intera
manifest.webmanifest  per l'installazione sul telefono
sw.js                 cache offline
icon.svg              icona
```
